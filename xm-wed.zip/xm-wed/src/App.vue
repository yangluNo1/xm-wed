<template>
  <div id="app">
      <router-view></router-view>
  </div>
</template>

<script>
export default {
 name: 'App',
 components:{}
}
</script>

<style>
html,body{
    background: #eeeeee;
    padding: 0;
    margin: 0;
}
</style>
