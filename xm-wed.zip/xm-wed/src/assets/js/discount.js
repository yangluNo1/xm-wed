
function fn (){
  $(document).ready(function(){

    $('.slider1').bxSlider({

      slideWidth: 350,

      minSlides: 2,

      maxSlides: 3,

      slideMargin: 10

    });

  });


  
  }
  module.exports = fn