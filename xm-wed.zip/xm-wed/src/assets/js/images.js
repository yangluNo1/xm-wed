function fn(){
    $(function(){

        //图片事件,img-gather处为仿qq空间图片效果展示
    
        $('#thumbs a').touchTouch();
    
    });
}
module.exports = fn

