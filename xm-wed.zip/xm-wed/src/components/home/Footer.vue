
  <template> 
   <div class="footer"> 
       {{copyright}}
      
   </div> 

  </template> 
  <script>

  var data="© 2008-2019 Wed114结婚网 | 蜀ICP备08107937号-1 |  关于我们  - 联系我们  - 招贤纳士  - 广告服务  - 商家入驻  - 免责声明 - 联系电话：028-84520690";
export default {
  name: 'Footer',
  data () {
    return {
      copyright: data
    }
  }
}
</script> 
  <!-- Add "scoped" attribute to limit CSS to this component only --> 
  <style scoped="">
.footer{
    width:100%;
    height: 50px;
  
    position: relative;
    bottom: 0;
    text-align: center;
    line-height: 50px;
    font-size: 12px;
}
</style> 
